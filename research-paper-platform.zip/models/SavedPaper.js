const mongoose=require('mongoose');
const schema=new mongoose.Schema({paperId:{type:mongoose.Schema.Types.ObjectId,ref:'ResearchPaper',required:true},notes:String,tags:[String],status:{type:String,default:'To Read'},savedAt:{type:Date,default:Date.now}});
module.exports=mongoose.model('SavedPaper',schema);
