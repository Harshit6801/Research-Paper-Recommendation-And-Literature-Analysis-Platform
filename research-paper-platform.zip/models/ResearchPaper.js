const mongoose=require('mongoose');
const schema=new mongoose.Schema({title:{type:String,required:true},authors:[String],abstract:String,keywords:[String],researchArea:String,publicationYear:Number,journal:String,citationCount:{type:Number,default:0},methodology:String,dataset:String,results:String,limitations:String,paperUrl:String,createdAt:{type:Date,default:Date.now}});
module.exports=mongoose.model('ResearchPaper',schema);
