require('dotenv').config();
const express=require('express'); const cors=require('cors'); const mongoose=require('mongoose'); const path=require('path');
const paperRoutes=require('./routes/paperRoutes'); const recommendationRoutes=require('./routes/recommendationRoutes'); const analysisRoutes=require('./routes/analysisRoutes'); const savedRoutes=require('./routes/savedPaperRoutes');
const app=express(); app.use(cors()); app.use(express.json()); app.use(express.static(path.join(__dirname,'public')));
app.use('/api/papers',paperRoutes); app.use('/api/recommendations',recommendationRoutes); app.use('/api/analysis',analysisRoutes); app.use('/api/saved-papers',savedRoutes);
app.get('/api/health',(req,res)=>res.json({ok:true,message:'Research platform API is running'}));
app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
const PORT=process.env.PORT||5000;
async function start(){try{await mongoose.connect(process.env.MONGODB_URI||'mongodb://127.0.0.1:27017/research_paper_platform'); console.log('MongoDB connected'); app.listen(PORT,()=>console.log(`Server running at http://localhost:${PORT}`));}catch(e){console.error('MongoDB connection failed:',e.message); console.log('Start MongoDB or set MONGODB_URI in .env');}}
start();
