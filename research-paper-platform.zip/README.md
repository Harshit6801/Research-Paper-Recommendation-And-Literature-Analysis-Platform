# Research Paper Recommendation & Literature Analysis Platform

A beginner-friendly full-stack MVP for discovering, recommending, comparing, and analyzing research-paper metadata.

## Stack
HTML5, CSS3, Vanilla JavaScript, Node.js, Express.js, MongoDB, Mongoose, Chart.js.

## Run locally
1. Install Node.js and MongoDB (or use MongoDB Atlas).
2. Copy `.env.example` to `.env` and set `MONGODB_URI`.
3. Run `npm install`.
4. Run `node data/seed.js` to insert demo data.
5. Run `npm start`.
6. Open http://localhost:5000

## Important
Seed records are demo metadata for testing and are not verified scholarly records or real citation claims.
