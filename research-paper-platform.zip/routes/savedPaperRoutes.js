const r=require('express').Router(),Saved=require('../models/SavedPaper');
r.get('/',async(req,res)=>res.json(await Saved.find().populate('paperId').sort({savedAt:-1})));
r.post('/',async(req,res)=>{try{res.status(201).json(await Saved.create(req.body));}catch(e){res.status(400).json({message:e.message});}});
r.delete('/:id',async(req,res)=>{try{await Saved.findByIdAndDelete(req.params.id);res.json({message:'Removed'});}catch(e){res.status(400).json({message:e.message});}}); module.exports=r;
